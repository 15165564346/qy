import { describe, it } from 'vitest'

describe('test goodMorning', () => {
  it('work', async () => {})
})
